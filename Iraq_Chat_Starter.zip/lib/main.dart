import 'package:flutter/material.dart';

void main() {
  runApp(const IraqChatApp());
}

class IraqChatApp extends StatelessWidget {
  const IraqChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Iraq Chat',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0D10),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF16A34A),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  final rooms = const [
    ('سهرة عراقية 🇮🇶', 'قصي السراي', 128),
    ('دردشة وأصدقاء', 'Iraq Chat', 76),
    ('أغاني وموسيقى 🎵', 'Ali', 54),
    ('شباب العراق', 'Mustafa', 39),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Iraq Chat',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                colors: [Color(0xFF151A20), Color(0xFF101B15)],
              ),
            ),
            child: const Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Color(0xFF16A34A),
                  child: Icon(Icons.graphic_eq_rounded, size: 30),
                ),
                SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('دردشة صوتية عراقية',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 5),
                      Text('تواصل، تكلم، وتعرّف على أصدقاء جدد'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text('الغرف الصوتية',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...rooms.map((room) => RoomCard(
                title: room.$1,
                owner: room.$2,
                users: room.$3,
              )),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _createRoom(context),
        icon: const Icon(Icons.add),
        label: const Text('إنشاء غرفة'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: 'الرئيسية'),
          NavigationDestination(
              icon: Icon(Icons.groups_outlined),
              selectedIcon: Icon(Icons.groups),
              label: 'الأصدقاء'),
          NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: 'حسابي'),
        ],
      ),
    );
  }

  void _createRoom(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => const CreateRoomSheet(),
    );
  }
}

class RoomCard extends StatelessWidget {
  final String title;
  final String owner;
  final int users;

  const RoomCard({
    super.key,
    required this.title,
    required this.owner,
    required this.users,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => VoiceRoomPage(title: title, owner: owner),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              const CircleAvatar(
                radius: 27,
                child: Icon(Icons.mic_rounded),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 5),
                    Text('المضيف: $owner'),
                  ],
                ),
              ),
              Column(
                children: [
                  const Icon(Icons.people_alt_outlined, size: 19),
                  Text('$users'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CreateRoomSheet extends StatefulWidget {
  const CreateRoomSheet({super.key});

  @override
  State<CreateRoomSheet> createState() => _CreateRoomSheetState();
}

class _CreateRoomSheetState extends State<CreateRoomSheet> {
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 22,
        bottom: MediaQuery.of(context).viewInsets.bottom + 22,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('إنشاء غرفة صوتية',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          TextField(
            controller: controller,
            decoration: const InputDecoration(
              labelText: 'اسم الغرفة',
              prefixIcon: Icon(Icons.meeting_room_outlined),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.check),
            label: const Text('إنشاء'),
          ),
        ],
      ),
    );
  }
}

class VoiceRoomPage extends StatefulWidget {
  final String title;
  final String owner;

  const VoiceRoomPage({super.key, required this.title, required this.owner});

  @override
  State<VoiceRoomPage> createState() => _VoiceRoomPageState();
}

class _VoiceRoomPageState extends State<VoiceRoomPage> {
  bool muted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          const SizedBox(height: 25),
          Text('المضيف: ${widget.owner}'),
          const SizedBox(height: 25),
          Expanded(
            child: GridView.count(
              crossAxisCount: 3,
              padding: const EdgeInsets.all(18),
              children: List.generate(
                9,
                (i) => Column(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      child: Icon(i == 0 ? Icons.person : Icons.mic_none),
                    ),
                    const SizedBox(height: 6),
                    Text(i == 0 ? widget.owner : 'مستخدم ${i + 1}'),
                  ],
                ),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton.filledTonal(
                  onPressed: () => setState(() => muted = !muted),
                  icon: Icon(muted ? Icons.mic_off : Icons.mic),
                  tooltip: muted ? 'تشغيل الميكروفون' : 'كتم الميكروفون',
                ),
                IconButton.filledTonal(
                  onPressed: () {},
                  icon: const Icon(Icons.chat_bubble_outline),
                ),
                IconButton.filledTonal(
                  onPressed: () {},
                  icon: const Icon(Icons.card_giftcard),
                ),
                IconButton.filled(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.call_end),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}